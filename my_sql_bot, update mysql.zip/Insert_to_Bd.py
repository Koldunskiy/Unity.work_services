import mysql.connector
from datetime import datetime

CONFIG = {
    'user': 'tester',
    'password': '250807',
    'host': '192.168.1.6',
    'port': '3306',
    'raise_on_warnings': True
}

# Получение текущего времени
current_time = datetime.now()

# Форматирование времени до минут в формате "ггггммддд чч:мм"
formatted_time = current_time.strftime("%Y-%m-%d %H:%M")
config = CONFIG

result = (120401.66000000005, 35268.0, 142472.79000000007, -9.449999999999964, 1060.0, -320.0, formatted_time)


sql = '''
Select * from mt5dashboard.daily
'''
try:
    # Установить соединение с базой данных
    connection = mysql.connector.connect(**config)
    print('Установленно соединение')
    # Создать объект cursor для выполнения SQL-запросов
    cursor = connection.cursor()

    # SQL-запрос для вставки данных
    query = 'INSERT INTO mt5dashboard.instant ( balance, credit, equity, profit, deposit, withdraw,rectime) VALUES (%s, %s, %s, %s, %s, %s, %s)'

    # Выполнить запрос на вставку данных
    cursor.execute(query, result)
    
    # Подтвердить изменения
    connection.commit()


    # Получить результаты запроса
    results = cursor.fetchall()

    # Вывести результаты
    for row in results:
        print(row)
    
    cursor.close()
    connection.close()
except Exception as e:
    print("Ошибка при работе c MySQL:", e)
# Закрыть курсор и соединение
