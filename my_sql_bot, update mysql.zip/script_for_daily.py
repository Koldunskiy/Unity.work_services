import mysql.connector
import pandas as pd
from settings import CONFIG_1, CONFIG_2, SQL_1, SQL_2, SQL_3
import time as time_sleep
from datetime import datetime, time as dt_time
from datetime import datetime, timedelta
import requests

TOKEN = '6766212755:AAGNwQDGrFoICY4s3WwHLBY0tH55AY6U01c'
URL = 'https://api.telegram.org/bot'
chat_id = -4017930976




def send_message(text:str):
    res = requests.get('https://api.telegram.org/bot{}/sendMessage'.format(TOKEN),
                       params={'chat_id': chat_id, 'text': text})
    return res.json()


def connect_to_db_daily():
    Flag = False
    while Flag!=True:
        try:
            connection = mysql.connector.connect(**CONFIG_1)
            # Создать объект cursor для выполнения SQL-запросов
            cursor = connection.cursor()
            cursor.execute(SQL_2)
            # Получить результаты запроса
            results1 = cursor.fetchall()
            # df = pd.read_sql(sql, connection)
            cursor.execute(SQL_3)
            # Получить результаты запроса
            results2 = cursor.fetchall()
            cursor.close()
            connection.close()
            result = results1[0] + results2[0] # Формирую единый список
            Flag = True
            return list(result)     
        except Exception as e:
            send_message("Ошибка при получении данных из БД MT5 для обнавления daily table. Повторная попытка через 10 сек...", e)
            dt_time.sleep(10)


def insert_into_daily_db():
    Flag = False
    while Flag != True:
        try:
            # Получение текущего времени
            current_time = datetime.now()
            # Прибавление 3 часов к текущему времени
            time_after_3_hours = current_time + timedelta(hours= 3 - 24)
            # Форматирование времени до минут в формате "ггггммддд чч:мм"
            formatted_time = time_after_3_hours.strftime("%Y-%m-%d")
            # Установить соединение с базой данных
            result = connect_to_db_daily()
            
            result.append(formatted_time)
            connection = mysql.connector.connect(**CONFIG_2)
            # Создать объект cursor для выполнения SQL-запросов
            cursor = connection.cursor()
            # SQL-запрос для вставки данных
            query = 'INSERT INTO mt5dashboard.daily (balance, credit, equity, acc_count, profit, deposit, withdraw, acc_active, rectime) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)'
            # Выполнить запрос на вставку данных
            cursor.execute(query, result) 
            # Подтвердить изменения
            connection.commit()
            # Получить результаты запроса
            results = cursor.fetchall()
            connection.close()

            Flag = True
        except Exception as e:
            # send_message(f"Ошибка при записи данных в БД. Повторная попытка через 10 сек...{e}")
            send_message((f"Ошибка при записи данных в БД в daily table. Повторная попытка через 10 сек...{e}"))
            dt_time.sleep(10)


#==============================
'''Скрипт для поминутного обнавления  mt5dashboard.tnvr_instant '''
SQL_4 = '''
-- внутри Дневной показатель  
WITH Temp_2 AS (
    SELECT deals.*, users.Group
    FROM mt5r1.mt5_deals AS deals
    JOIN mt5r1.mt5_users AS users ON deals.Login = users.Login
    WHERE SUBSTRING(users.Group, 1, 12) = 'real\\\\neobit\\\\' and deals.Symbol <> '' AND Time >= CURDATE()
)
SELECT 
Symbol,
sum(ContractSize * Volume / 10000),
sum(ContractSize * Volume * Price / 10000),
count(ContractSize),
date(`Time`)
FROM Temp_2
group by date(`Time`),Symbol
;'''

 

def check_all_none(lst):
    return all(value is None for value in lst)

def get_data_2()-> list:
    Flag = False
    while Flag!=True:
        try:
            connection = mysql.connector.connect(**CONFIG_1)
            # Создать объект cursor для выполнения SQL-запросов
            cursor = connection.cursor()
            cursor.execute(SQL_4)
            # Получить результаты запроса
            result = cursor.fetchall()
            cursor.close()
            connection.close()
            Flag = True
            return list(result)     
        except Exception as e:
            send_message("Ошибка при получении данных из БД MT5. Минутное обновление сделок для таблицы tnvr_daily. Повторная попытка через 10 сек...", e)
            time_sleep.sleep(10)

# print(get_data_2())

def insert_into_db_2():
    Flag = False
    while Flag != True:
        try:
          
    
            result = get_data_2()
            if check_all_none(result) == False:
        
                connection = mysql.connector.connect(**CONFIG_2)
                # Создать объект cursor для выполнения SQL-запросов
                cursor = connection.cursor()
                # SQL-запрос для вставки данных

                for row in result:
                    symbol = row[0]
                    row = list(row[:4])
                    current_time = datetime.now()
                    # Прибавление 3 часов к текущему времени
                    time_after_3_hours = current_time + timedelta(hours=3)
                    # Форматирование времени до минут в формате "ггггммддд чч:мм"
                    formatted_time = time_after_3_hours.strftime("%Y-%m-%d %H:%M")
                    row.append(formatted_time)
                    
                    # Используйте параметры в запросе для передачи значения symbol
                    SQL_5 = '''
                            SELECT count(symbol) FROM mt5dashboard.tnvr_instant
                            where rectime >= CURDATE() and symbol = %s
                    '''

                    # Передача значения symbol как параметра при выполнении запроса
                    cursor.execute(SQL_5, (symbol,))
                    results = cursor.fetchall()
    
                    # return results    
                    # results row
                    if results[0][0] == 0:
                        #print('INSERT')
                        query = 'INSERT INTO mt5dashboard.tnvr_instant (symbol, tnvr_ccy, tnvr_ctr, trade_count, rectime) VALUES (%s, %s, %s, %s, %s)'
                        # Выполнить запрос на вставку данных
                        cursor.execute(query, row) 
                        # Подтвердить изменения
                        connection.commit()

                        # Получить результаты запроса
                        results = cursor.fetchall()

                    else: 
                        #print('UPDATE')
                        query = f'UPDATE mt5dashboard.tnvr_instant SET rectime = %s, tnvr_ccy = %s, tnvr_ctr = %s, trade_count = %s WHERE Symbol = %s'
                        cursor.execute(query, (row[4], row[1], row[2], row[3], symbol))
                  
                        # Подтвердить изменения
                        connection.commit()

                        # Получить результаты запроса
                        results = cursor.fetchall()
                connection.close()
                
            Flag = True
        except Exception as e:
            # send_message(f"Ошибка при записи данных в БД. Повторная попытка через 10 сек...{e}")
            send_message((f"Ошибка при записи данных в БД. Повторная попытка через 10 сек...{e}"))
            time_sleep.sleep(10)




#==================================
'''Скрипт для обнавления tnvr_daily'''

# SQL_6 = '''
# -- Дневной показатель
# WITH Teble AS (

# 	WITH Temp_2 AS (
# 		SELECT deals.*, users.Group
# 		FROM mt5r1.mt5_deals AS deals
# 		JOIN mt5r1.mt5_users AS users ON deals.Login = users.Login
# 		WHERE SUBSTRING(users.Group, 1, 12) = 'real\\neobit\\' and deals.Symbol <> ''
# 	)
# 	SELECT 
# 	date(`Time`) as `Date`,
# 	Symbol,
# 	sum(ContractSize * Volume),
# 	sum(ContractSize * Volume * Price),
# 	count(ContractSize)
# 	FROM Temp_2
# 	group by date(`Time`),Symbol
# 	)
# SELECT *
# #count(Symbol)
# FROM Teble
# where `Date` = '2023-11-28'
# #WHERE Symbol = %s
# ;'''

def insdert_data_to_tnvr_daily():
    Flag = False
    while Flag != True:
        try:
            current_time = datetime.now()
            # Прибавление 3 часов к текущему времени
            time_after_3_hours = current_time + timedelta(hours=3-24)
            # Форматирование времени до минут в формате "ггггммддд чч:мм"
            formatted_time = time_after_3_hours.strftime("%Y-%m-%d")
            SQL_6 = '''
                -- Дневной показатель
                WITH Teble AS (

                    WITH Temp_2 AS (
                        SELECT deals.*, users.Group
                        FROM mt5r1.mt5_deals AS deals
                        JOIN mt5r1.mt5_users AS users ON deals.Login = users.Login
                        WHERE SUBSTRING(users.Group, 1, 12) = 'real\\\\neobit\\\\' and deals.Symbol <> ''
                    )
                    SELECT 
                    date(`Time`) as `Date`,
                    Symbol,
                    sum(ContractSize * Volume / 10000),
                    sum(ContractSize * Volume * Price / 10000),
                    count(ContractSize)
                    FROM Temp_2
                    group by date(`Time`),Symbol
                    )
                SELECT *
            
                FROM Teble
                where `Date` =  %s
            
                ;'''
            connection = mysql.connector.connect(**CONFIG_1)
            # Создать объект cursor для выполнения SQL-запросов
            cursor = connection.cursor()
            df = pd.read_sql(SQL_6, connection, params=(formatted_time,))
            connection.close()
            df['Date'] = df['Date'].astype(str)
            #===================================
            connection = mysql.connector.connect(**CONFIG_2)
            # Создать объект cursor для выполнения SQL-запросов
            cursor = connection.cursor()

            for idex, value in df.iterrows():
                value = value.tolist()
                result = value
                query = 'INSERT INTO mt5dashboard.tnvr_daily (rectime, symbol, tnvr_ccy, tnvr_ctr, trade_count) VALUES (%s, %s, %s, %s, %s)'
                # Выполнить запрос на вставку данных
                cursor.execute(query, result) 
                # Подтвердить изменения
                connection.commit()
                # Получить результаты запроса
                results = cursor.fetchall()
            connection.close()
            Flag = True
        except Exception as e:
            # send_message(f"Ошибка при записи данных в БД. Повторная попытка через 10 сек...{e}")
            send_message((f"Ошибка при записи данных в БД mt5dashboard.tnvr_daily. Повторная попытка через 10 сек...{e}"))
            time_sleep.sleep(10)




def delete_db_tnvr_instant():
    connection = mysql.connector.connect(**CONFIG_2)
    # Создать объект cursor для выполнения SQL-запросов
    cursor = connection.cursor()
    sql = 'DELETE FROM mt5dashboard.tnvr_instant;'
    cursor.execute(sql) 
    # Подтвердить изменения
    connection.commit()
    # Получить результаты запроса
    cursor.fetchall()
    connection.close()
    
def delete_data_from_instant():
    current_time = datetime.now()

    time_after_3_hours = current_time + timedelta(hours=3 - 96)
    # Форматирование времени до минут в формате "ггггммддд чч:мм"
    right_data = time_after_3_hours.strftime("%Y-%m-%d")
    connection = mysql.connector.connect(**CONFIG_2)
    # Создать объект cursor для выполнения SQL-запросов
    cursor = connection.cursor()
    sql = 'DELETE FROM mt5dashboard.instant where rectime <= %s;'
    cursor.execute(sql, params = (right_data,)) 
    # Подтвердить изменения
    connection.commit()
    # Получить результаты запроса
    cursor.fetchall()
    connection.close()

