import mysql.connector
import pandas as pd
from settings import CONFIG_1, CONFIG_2, SQL_1, SQL_2, SQL_3
import time as time_sleep
from datetime import datetime, time as dt_time
from datetime import datetime, timedelta
import requests
from script_for_daily import  insert_into_daily_db, insert_into_db_2,insdert_data_to_tnvr_daily,delete_db_tnvr_instant,delete_data_from_instant 
TOKEN = '6766212755:AAGNwQDGrFoICY4s3WwHLBY0tH55AY6U01c'
URL = 'https://api.telegram.org/bot'
chat_id = -4017930976




def send_message(text:str):
    res = requests.get('https://api.telegram.org/bot{}/sendMessage'.format(TOKEN),
                       params={'chat_id': chat_id, 'text': text})
    return res.json()

def check_all_none(lst):
    new_spisok = []
    for i in lst:
        if i == None:
            new_spisok.append(0)
        else:
            new_spisok.append(i)
    return new_spisok



def get_data()-> list:
    Flag = False
    while Flag!=True:
        try:
            connection = mysql.connector.connect(**CONFIG_1)
            # Создать объект cursor для выполнения SQL-запросов
            cursor = connection.cursor()
            cursor.execute(SQL_1)
            # Получить результаты запроса
            results1 = cursor.fetchall()
            # df = pd.read_sql(sql, connection)
            cursor.execute(SQL_2)
            # Получить результаты запроса
            results2 = cursor.fetchall()
            cursor.close()
            connection.close()
            result = results2[0] + results1[0] # Формирую единый список
            Flag = True
            return list(result)     
        except Exception as e:
            send_message("Ошибка при получении данных из БД MT5. Повторная попытка через 10 сек...", e)
            time_sleep.sleep(10)


def insert_into_db():
    Flag = False
    while Flag != True:
        try:
            # Получение текущего времени
            current_time = datetime.now()
            # Прибавление 3 часов к текущему времени
            time_after_3_hours = current_time + timedelta(hours=3)
            # Форматирование времени до минут в формате "ггггммддд чч:мм"
            formatted_time = time_after_3_hours.strftime("%Y-%m-%d %H:%M")
            # Установить соединение с базой данных
            result = get_data()
            result = check_all_none(result)
            result.append(formatted_time)
            connection = mysql.connector.connect(**CONFIG_2)
            # Создать объект cursor для выполнения SQL-запросов
            cursor = connection.cursor()
            # SQL-запрос для вставки данных
            query = 'INSERT INTO mt5dashboard.instant (balance, credit, equity, acc_count, profit, deposit, withdraw, acc_active, rectime) VALUES (%s, %s, %s, %s, %s, %s, %s, %s,%s)'
            # Выполнить запрос на вставку данных
            cursor.execute(query, result) 
            # Подтвердить изменения
            connection.commit()
            # Получить результаты запроса
            results = cursor.fetchall()
            connection.close()
                
            Flag = True
        except Exception as e:
            # send_message(f"Ошибка при записи данных в БД. Повторная попытка через 10 сек...{e}")
            send_message((f"Ошибка при записи данных в БД. Повторная попытка через 10 сек...{e}"))
            time_sleep.sleep(10)


def update_daily_tb(future_date):
    current_time = datetime.now()
    # Прибавление 3 часов к текущему времени
    time_after_3_hours = current_time + timedelta(hours=3)
    # Форматирование времени до минут в формате "ггггммддд чч:мм"
    formatted_time = time_after_3_hours.strftime("%Y-%m-%d")
    if future_date == formatted_time:
        time_after_3_hours = current_time + timedelta(hours=3-24)
        # Форматирование времени до минут в формате "ггггммддд чч:мм"
        formatted_time = time_after_3_hours.strftime("%Y-%m-%d")
        insert_into_daily_db()
        insdert_data_to_tnvr_daily()
        send_message(f'Дневные данные за {formatted_time} успешно вставленны в 2 БД daily')
        delete_db_tnvr_instant()
        return True
    return False



print('__Работаем__')
if __name__ == "__main__":
    while True:
        try:
            Flag = False
            current_time = datetime.now()
            # Прибавление 3 часов к текущему времени
            time_after_3_hours = current_time + timedelta(hours= 3 + 24)
            # Форматирование времени до минут в формате "ггггммддд чч:мм"
            future_date = time_after_3_hours.strftime("%Y-%m-%d")
            delete_data_from_instant()
            while Flag != True:
                Flag = update_daily_tb(future_date)
                insert_into_db()
                insert_into_db_2()
                time_sleep.sleep(60)
        except:
            time_sleep.sleep(10)