CONFIG_1 = {
    'user': 'neo_reports',
    'password': 'gh2uyti56hgk2h',
    'host': '92.38.186.22',
    'port': '3306',
    'raise_on_warnings': True
}

CONFIG_2 = {
    'user': 'tester',
    'password': 'Fx123456#',
    'host': '192.168.1.6',
    'port': '3306',
    'raise_on_warnings': True
}


SQL = '''
WITH Temp_2 AS (
    WITH Temp_table AS (
        SELECT deals.*, users.Group
        FROM mt5r1.mt5_deals AS deals
        JOIN mt5r1.mt5_users AS users ON deals.Login = users.Login
        WHERE SUBSTRING(users.Group, 1, 12) = 'real\\\\neobit\\\\' AND Time >= CURDATE()
    ),
    Another_table AS (
        SELECT mt5r1.mt5_accounts.Login AS Account_Login, mt5r1.mt5_accounts.Balance, mt5r1.mt5_accounts.Credit, mt5r1.mt5_accounts.Equity
        FROM mt5r1.mt5_accounts
    )
    SELECT Temp_table.*, Another_table.Balance, Another_table.Credit, Another_table.Equity
    FROM Temp_table
    JOIN Another_table ON Temp_table.Login = Another_table.Account_Login
)
SELECT 
	sum(Balance) as 'Balance',
    sum(Credit) as 'Credit',
    sum(Equity) as 'Equity',
    SUM(CASE WHEN Symbol <> '' THEN Profit ELSE 0 END) AS Profit,
	SUM(CASE WHEN Symbol = '' AND Profit >= 0 THEN Profit ELSE 0 END) AS Deposit,
    SUM(CASE WHEN Symbol = '' AND Profit < 0 THEN Profit ELSE 0 END) AS Withdrawal
FROM Temp_2;
'''


SQL_1 = '''

with Temp_2 as (
SELECT deals.*, users.Group
         FROM 
             mt5r1.mt5_deals as deals
         JOIN 
             mt5r1.mt5_users as users ON deals.Login = users.Login
         WHERE 
         SUBSTRING(users.Group, 1, 12) = 'real\\\\neobit\\\\' AND Time >= CURDATE())        
select 
SUM(CASE WHEN Symbol <> '' THEN Profit ELSE 0 END) AS Profit,
SUM(CASE WHEN Symbol = '' AND Profit >= 0 and Dealer!=0 THEN Profit ELSE 0 END) AS Deposit,
SUM(CASE WHEN Symbol = '' AND Profit < 0 and Dealer!=0 THEN Profit ELSE 0 END) AS Withdrawal,
count(DISTINCT (Login)) as 'Daily activity client'
from Temp_2;
'''
SQL_2 = '''
SELECT 
             SUM(accounts.Balance) as "Total Balance",
             SUM(accounts.Credit) as "Total Credit",
             SUM(accounts.Equity) as "Total Equity",
             count(DISTINCT(accounts.Login)) as 'Uniq users at all'
         FROM 
             mt5r1.mt5_accounts as accounts
         JOIN 
             mt5r1.mt5_users as users ON accounts.Login = users.Login
         WHERE 
         SUBSTRING(users.Group, 1, 12) = 'real\\\\neobit\\\\';'''


'''Возвращет профит и прочиее за 1 день'''
SQL_3 = '''
WITH Temp_2 AS (
    SELECT deals.*, users.Group
    FROM mt5r1.mt5_deals AS deals
    JOIN mt5r1.mt5_users AS users ON deals.Login = users.Login
    WHERE SUBSTRING(users.Group, 1, 12) = 'real\\\\neobit\\\\' 
)
SELECT 
SUM(CASE WHEN Symbol <> '' THEN Profit ELSE 0 END) AS Profit,
SUM(CASE WHEN Symbol = '' AND Profit >= 0 and Dealer!=0 THEN Profit ELSE 0 END) AS Deposit,
SUM(CASE WHEN Symbol = '' AND Profit < 0 and Dealer!=0 THEN Profit ELSE 0 END) AS Withdrawal,
count(DISTINCT (Login)) as 'Daily activity client'
FROM Temp_2
group by  Date(`Time`) 
order by  Date(`Time`) 
Desc 
LIMIT 1 
-- OFFSET 1
;
'''

# sql_requsts = {
# "task_1": '''
#         SELECT 
#             SUM(accounts.Balance) as "Total Balance",
#             SUM(accounts.Credit) as "Total Credit",
#             SUM(accounts.Equity) as "Total Equity",
#             SUM(accounts.Profit) as "Total Profit"
#         FROM 
#             mt5r1.mt5_accounts as accounts
#         JOIN 
#             mt5r1.mt5_users as users ON accounts.Login = users.Login
#         WHERE 
#         SUBSTRING(users.Group, 1, 12) = 'real\\\\neobit\\\\';
#         ''',

# 'task_2': '''
#         SELECT sum(deals.Volume * deals.ContractSize) as TotalSum
#         FROM mt5r1.mt5_deals as deals
#         JOIN mt5r1.mt5_users as users ON deals.Login = users.Login
#         WHERE 
#         SUBSTRING(users.Group, 1, 12) = 'real\\\\neobit\\\\' and '2023-11-07' <= Time and Time < '2023-11-08'
#         ''',

# 'task_3': '''
#         with Temp_table  as (
#             SELECT deals.*, users.Group
#             FROM mt5r1.mt5_deals as deals
#             JOIN mt5r1.mt5_users as users ON deals.Login = users.Login
#             WHERE 
#             SUBSTRING(users.Group, 1, 12) = 'real\\neobit\\' and '2023-06-07' <= Time and Time < '2023-11-027'
#         )
            
#         SELECT
#             SUM(CASE WHEN Symbol = '' AND Profit < 0 THEN Profit ELSE 0 END) AS Withdrawal,
#             SUM(CASE WHEN Symbol = '' AND Profit >= 0 THEN Profit ELSE 0 END) AS Deposit,
#             SUM(CASE WHEN Symbol <> '' THEN Profit ELSE 0 END) AS Balance
#         FROM Temp_table;'''
# }


# # pandas 
# df = pd.read_sql(query, connection)
# print(df)