from playwright.sync_api import Playwright, sync_playwright, expect
import time

def run(playwright: Playwright) -> None:
    browser = playwright.chromium.launch(headless=False)
    context = browser.new_context()
    page = context.new_page()
    page.goto("https://app.leonardo.ai/auth/login")
    page.get_by_placeholder("name@host.com").click()
    page.get_by_placeholder("name@host.com").click()
    page.get_by_placeholder("name@host.com").fill("razumowskij.boris@yandex.ru")
    page.get_by_placeholder("Password").click()
    page.get_by_placeholder("Password").fill("123QazWsxEdc")
    page.get_by_role("button", name="Sign in").click()
    time.sleep(7)
    page.get_by_label("Close Modal").click()
    for _ in range(5):
        # Скроллинг страницы вниз
        page.evaluate("window.scrollTo(0, document.body.scrollHeight);")
        
        # Дождитесь подгрузки контента после скроллинга
        time.sleep(5)  # В идеале использовать методы ожидания Playwright
    
    # Получение HTML кода страницы
    page_html = page.content()
    
    # Сохранение HTML кода в файл
    with open("page_content.html", "w", encoding="utf-8") as f:
        f.write(page_html)
    

    # ---------------------
    context.close()
    browser.close()


with sync_playwright() as playwright:
    run(playwright)

# import json
# from playwright.async_api import async_playwright
# import time
# async def main():
#     async with async_playwright() as p:
#         browser = await p.chromium.launch(headless=False) # Используйте headless=False для визуального контроля
#         context = await browser.new_context()

#         # Здесь происходит процесс регистрации
#         page = await context.new_page()
#         await page.goto("https://app.leonardo.ai/auth/login")
#         await page.get_by_placeholder("name@host.com").click()
#         await page.get_by_placeholder("name@host.com").fill("razumowskij.boris@yandex.ru")
#         await page.get_by_placeholder("Password").fill("123QazWsxEdc")
#         await page.get_by_role("button", name="Sign in").click()
#         time.sleep(30)
      


#         await browser.close()

# import asyncio
# if __name__ == '__main__':
#     asyncio.run(main())
        
# import json
# from playwright.sync_api import sync_playwright

# def main():
#     with sync_playwright() as p:
#         browser = p.chromium.launch(headless=False)  # Или True, если не хотите видеть UI
#         context = browser.new_context()

#         # Путь к файлу с cookies
#         cookies_path = r'C:\Users\Python\Documents\Vs code\Веб скрапинг\cookies_for_leonardo_AI.json'

#         # Загрузка cookies
#         with open(cookies_path, 'r') as cookies_file:
#             cookies = json.load(cookies_file)
#             context.add_cookies(cookies)

#         # Открытие страницы после установки cookies
#         page = context.new_page()
#         page.goto("https://app.leonardo.ai")
#         time.sleep(30)
        
#         # Дальнейшие действия на сайте...
        
#         browser.close()

# if __name__ == '__main__':
#     main()
